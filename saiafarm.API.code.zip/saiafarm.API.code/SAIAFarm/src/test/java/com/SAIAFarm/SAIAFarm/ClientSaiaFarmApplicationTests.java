package com.SAIAFarm.SAIAFarm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientSaiaFarmApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.Irrigation.SAIAFarming.repository;

import com.Irrigation.SAIAFarming.entity.ParcelDatabase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParcelDatabaseRepository extends JpaRepository<ParcelDatabase, Integer> {
}

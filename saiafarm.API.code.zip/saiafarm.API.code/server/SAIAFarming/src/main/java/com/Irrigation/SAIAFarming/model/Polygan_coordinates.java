/*
//package com.Irrigation.SAIAFarming.model;
//
//
//import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
//import com.fasterxml.jackson.databind.annotation.JsonSerialize;
//import org.locationtech.jts.geom.Geometry;
//import org.n52.jackson.datatype.jts.GeometryDeserializer;
//import org.n52.jackson.datatype.jts.GeometrySerializer;
//
//import java.awt.*;
//
//
//public class Polygan_coordinates {
//
//
//    @JsonSerialize(using = GeometrySerializer.class)
//    @JsonDeserialize(using = GeometryDeserializer.class)
//    Polygon coordinates;
//
//    public Polygan_coordinates() {
//        this.coordinates = coordinates;
//    }
//
//    public Geometry getCoordinates() {
//        return coordinates;
//    }
//
//
//
//}
//
*/

package com.Irrigation.SAIAFarming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaiaFarmingApplicationTests {

	@Test
	void contextLoads() {
	}

}

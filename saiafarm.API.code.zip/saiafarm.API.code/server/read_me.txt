##########Sample body data to POST polygan data############(first register a user to use this API)


{
    "type": "Feature",
    "properties": {
        "user_id":"anch5330",
        "head_name":"",
        "gender": "Male",
        "son_wife_daughter":"xyz",
        "literacy":"10",
        "village":"kamand new place",
        "address_landmark":"near new place 25-05-2022"

    },
    "geometry": {
        "type": "Polygon",
        "coordinates": [
            [
                [18.5016632080, 54.5186902372369],
                [18.5009765625, 54.4488835908718],
                [18.4467315673, 54.4101394181849],
                [18.4748840332, 54.3961505667008],
                [18.5270690917, 54.5194873388633],
                [18.5016632080, 54.5186902372369]
            ]
        ]
    }}
